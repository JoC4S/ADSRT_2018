#!/bin/bash

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/josecs/Escritorio/ADSRT_2018/src/ex2/lib
/home/josecs/Escritorio/ADSRT_2018/src/ex2/parcial parcial.db
